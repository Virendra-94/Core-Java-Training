package oopsdemo2;

/**
* Author : Virendra.1.Kumar
* Date   : Jul 10, 2025
* Time   : 12:16:29 PM
* Email  : Virendra.1.Kumar@coforge.com
*/

public class Publisher {

	String name;

	  String publisherID;

	  String city;

	  public Publisher(String name, String publisherID, String city) {

	 this.name = name;

	 this.publisherID = publisherID;

	 this.city = city;

	  }
}

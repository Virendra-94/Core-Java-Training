package oopsdemo2;

/**
* Author : Virendra.1.Kumar
* Date   : Jul 10, 2025
* Time   : 10:08:38 AM
* Email  : Virendra.1.Kumar@coforge.com
*/

public class Address {

	String city, state, country;
	int pincode;
	
	
	public Address(String city, String state, String country, int pincode) {
		this.city = city;
		this.state = state;
		this.country = country;
		this.pincode = pincode;
	}
	
	
	
	
}

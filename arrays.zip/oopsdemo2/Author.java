package oopsdemo2;

/**
* Author : Virendra.1.Kumar
* Date   : Jul 10, 2025
* Time   : 12:16:17 PM
* Email  : Virendra.1.Kumar@coforge.com
*/

public class Author {
	 String authorName;

	 int age;

	 String place;

	 public Author(String authorName, int age, String place) {

	 this.authorName = authorName;

	 this.age = age;

	 this.place = place;
	 }
	
}

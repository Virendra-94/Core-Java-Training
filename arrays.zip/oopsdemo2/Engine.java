package oopsdemo2;

/**
* Author : Virendra.1.Kumar
* Date   : Jul 10, 2025
* Time   : 12:29:02 PM
* Email  : Virendra.1.Kumar@coforge.com
*/

public class Engine {

	void startEngine()
	{
		System.out.println("Car Engine Started");
	}
	
	void stopEngine()
	{
		System.out.println("Car Engine Stoped");
	}
}

package oopsdemo4;

/**
* Author : Virendra.1.Kumar
* Date   : Jul 11, 2025
* Time   : 2:49:18 PM
* Email  : Virendra.1.Kumar@coforge.com
*/

public class SamsungCalculatorTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SamsungCalculator samsungCalculator = new SamsungCalculator();
		samsungCalculator.display();
		samsungCalculator.add();
		samsungCalculator.sub();
		samsungCalculator.mul();
		samsungCalculator.div();

	}

}

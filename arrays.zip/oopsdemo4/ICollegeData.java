package oopsdemo4;

/**
* Author : Virendra.1.Kumar
* Date   : Jul 11, 2025
* Time   : 4:06:23 PM
* Email  : Virendra.1.Kumar@coforge.com
*/

public interface ICollegeData {

	public void collegeDetail();
	public void studentData();
	
}

interface IHostelData{
	public void hostelDetail();
	public void studentRecord();
}
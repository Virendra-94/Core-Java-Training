package oopsdemo4;

/**
* Author : Virendra.1.Kumar
* Date   : Jul 11, 2025
* Time   : 2:38:10 PM
* Email  : Virendra.1.Kumar@coforge.com
*/

public interface ICalculator {

	//by default public abstract methods
	public void add();
	public void sub();
	void mul();
	public abstract void div();
}

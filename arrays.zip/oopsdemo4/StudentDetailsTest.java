package oopsdemo4;

/**
* Author : Virendra.1.Kumar
* Date   : Jul 11, 2025
* Time   : 4:21:26 PM
* Email  : Virendra.1.Kumar@coforge.com
*/


public class StudentDetailsTest {

	public static void main(String[] args) {
		
		StudentDetails s1 = new StudentDetails();
		s1.collegeDetail();
		s1.studentData();
		
		s1.hostelDetail();
		s1.studentRecord();
	}

}

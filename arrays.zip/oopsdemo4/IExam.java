package oopsdemo4;

/**
* Author : Virendra.1.Kumar
* Date   : Jul 11, 2025
* Time   : 3:16:49 PM
* Email  : Virendra.1.Kumar@coforge.com
*/

public interface IExam {

	public abstract void percent_cal();
}

package controlflow;

public class CountVowles {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

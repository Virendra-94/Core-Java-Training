package controlflow;

public class SwitchDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

package controlflow;

public class Discount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

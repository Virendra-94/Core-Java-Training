/**
 * 
 */
package controlflow;

/**
 * 
 */
public class Greatest2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

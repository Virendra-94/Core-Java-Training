package controlflow;

public class SimpleIntrestCondition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

package basics;

public class SimpleIntrest {

}

package basics;

public class SumAvg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

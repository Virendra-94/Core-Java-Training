package oops;

/**
* Author : Virendra.1.Kumar
* Date   : Jul 9, 2025
* Time   : 12:17:59 PM
* Email  : Virendra.1.Kumar@coforge.com
*/

public class TimeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Time t1 = new Time(11, 59, 59);
		Time t2 = new Time(11, 59, 59);
		
		t1.add(t2);
		t1.display();
		


	}

}
